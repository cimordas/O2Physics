// Copyright 2019-2020 CERN and copyright holders of ALICE O2.
// See https://alice-o2.web.cern.ch/copyright for details of the copyright holders.
// All rights not expressly granted are reserved.
//
// This software is distributed under the terms of the GNU General Public
// License v3 (GPL Version 3), copied verbatim in the file "COPYING".
//
// In applying this license CERN does not waive the privileges and immunities
// granted to it by virtue of its status as an Intergovernmental Organization
// or submit itself to any jurisdiction.

// \brief   Calculation class for the AC-related analyses.
// \author  Cindy Mordasini (cindy.mordasini@cern.ch)

#ifndef PWGCF_FLOW_CORE_FLOWJSPCANALYSIS_H
#define PWGCF_FLOW_CORE_FLOWJSPCANALYSIS_H

/* Header files. */
#include <array>
#include <vector>
#include <TComplex.h>
#include <TProfile.h>

// O2 headers. //
#include "Framework/AnalysisDataModel.h"
#include "Framework/HistogramRegistry.h"
#include "Framework/StaticFor.h"

using namespace o2;
using namespace o2::framework;
using namespace std;

namespace o2::analysis::PWGCF {
class FlowJSPCAnalysis {
public:
	FlowJSPCAnalysis() = default;

	void SetHistRegistry(HistogramRegistry *histReg) {mHistRegistry = histReg;}
	Int_t GetCentBin(float cValue);
	void CalculateQvectors(const vector<float>& phiAngles, const vector<float>& phiWeights);
	void Correlation(Int_t c_nPart, Int_t c_nHarmo, Int_t* harmo, Double_t *correlData);
	void CalculateCorrelators(const Int_t fCentBin);
	void FillHistograms(const Int_t fCentBin, Int_t ind, Double_t cNum, Double_t cDenom, Double_t wNum, Double_t wDenom);
	TComplex Recursion(int n, int *harmonic, int mult, int skip);
	TComplex Q(const Int_t harmN, const Int_t p);

	void CreateHistos() {
		if (!mHistRegistry) {
			LOGF(error, "QA histogram registry missing. Quitting...");
			return;
		}
		mHistRegistry->add("FullCentrality", "FullCentrality", HistType::kTH1D, {{100, 0., 100.}}, true);
		mHistRegistry->add("Centrality_0/fResults", "Numerators and denominators", {HistType::kTProfile, {{24, 0., 24.}} }, true);
		mHistRegistry->add("Centrality_0/fCovResults", "Covariance N*D", { HistType::kTProfile, {{48, 0., 48.} }}, true);
		
		for (UInt_t i = 1; i<8; i++) {
			mHistRegistry->addClone("Centrality_0/", Form("Centrality_%u/", i));
		}
	}

private:
	const Int_t mNqHarmos = 113;   ///< Highest harmo for Q(n,p): (v8*14part)+1.
	const Int_t mNqPowers = 15;   ///< Max power for Q(n,p): 14part+1.
	// array<array<TComplex, mNqPowers>,mNqHarmos> cQvectors;
	TComplex cQvectors[113][15];
	HistogramRegistry *mHistRegistry = nullptr;


	     // All combinations of Q-vectors.
	Int_t fHarmosArray[12][8] = {
                    {3, 6,-3,-3, 0, 0, 0, 0},
                    {3, 4,-2,-2, 0, 0, 0, 0},
                    {3, 8,-4,-4, 0, 0, 0, 0},
                    {3, 2, 4,-6, 0, 0, 0,0},
                    {3, 2, 3,-5, 0, 0, 0,0},
                    {3, 3, 4, -7, 0, 0, 0,0}, // These are three harmonic SPC!!
                    {3, 2, 5, -7, 0, 0, 0,0}, // These are three harmonic SPC!!
                    {3, 3, 5, -8, 0, 0, 0,0}, // These are three harmonic SPC!!
                    {0, 6,-2,-2,-2, 0, 0, 0},
                    {0, 2,-3,-4, 5, 0, 0,0},
                    {0, 2,-3,-3, 4, 0, 0,0},
                    {0, 3, 3,-2,-2,-2, 0, 0}
	};        // Array of combinations of harmonics for the SPC.
	Double_t fCorrelDenoms[14];
	static constexpr std::string_view mCentClasses[] = {
		"Centrality_0/",
		"Centrality_1/",
		"Centrality_2/",
		"Centrality_3/",
		"Centrality_4/",
		"Centrality_5/",
		"Centrality_6/",
		"Centrality_7/",
		"Centrality_8/",
		"Centrality_9/"
	};

	ClassDefNV(FlowJSPCAnalysis, 1);
};
}
#endif
